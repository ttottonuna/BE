package org.kdt.mooluck.domain.interaction.service;

public interface InteractionService {
    void incrementPetCount(int elderId);
    void incrementWaterCount(int elderId);
}
